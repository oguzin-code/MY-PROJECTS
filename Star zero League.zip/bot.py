import discord
from discord.ext import commands
import json

with open("config.json", "r") as f:
    config = json.load(f)
    token = config["token"]

intents = discord.Intents.all()
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.command()
async def league(ctx):
    with open("teams.json", "r") as f:
        teams = json.load(f)
  
    league_sorted = sorted(teams.items(), key=lambda item: item[1], reverse=True)
    msg = "" 
    
    for i, (team, score) in enumerate(league_sorted, start=1):
        msg += f"> **{i} - ** {team} - **{score}** pts\n"
        
    await ctx.send(f"# - Tabela\n{msg}")


@bot.command()
async def add(ctx, name):
    with open("teams.json", "r") as f:
        teams = json.load(f)

        teams[name] = 0

        with open("teams.json", "w") as f:
            json.dump(teams, f, indent=4)

@bot.command()
async def victory(ctx, team1, point1, team2, point2):
    try:
        with open("teams.json", "r") as f:
            teams = json.load(f)
            tm1 = (teams[team1])
            tm2 = (teams[team2])

            if (point1) > (point2):
                with open("teams.json","w") as f:
                    teams[team1] += 3
                    json.dump(teams, f, indent=4)
                    await ctx.send(f"O time {team1} ganhou 3 pontos")

            elif (point1) < (point2):
                
                with open("teams.json","w") as f:
                    teams[team2] += 3
                    json.dump(teams, f, indent=4)
                    await ctx.send(f"O time {team2} ganhou 3 pontos")

            elif (point1) == (point2):
                with open("teams.json", "w") as f:
                    teams[team1] += 1
                    teams[team2] += 1
                    json.dump(teams, f, indent=4)
                    await ctx.send(f"Houve um empate, ambos os times {team1} e {team2}, ganharam 1 ponto na liga")
    except KeyError:
        await ctx.send("Time não encontrado")

@bot.command()
async def register(ctx):

    ide = str(ctx.author.id)
    name = ctx.author.name
 
    with open ("player.json", "r") as f:
        player = json.load(f)

    if ide not in player:

        player[ide] = {

        "discord_name": (name),
        "value": 0,
        "team": "nenhum",
        "points": 0

        }
        with open("player.json", "w") as f:
            json.dump(player, f, indent=4)

        await ctx.reply("Voçê foi registrado")

    else:
        await ctx.reply("**Você já ta registrado**")

@bot.command()
async def search(ctx, nick: discord.Member):
    
    ide = str(nick.id)
    name = str(f"<@{ide}>")
    try:
        with open("player.json", "r") as f:
            player = json.load(f)

        await ctx.reply(f"# Jogador - **{player[ide]["discord_name"]}**\n > - **Valor de mercado : ** **{player[ide]["value"]}**\n> - **Time :** **{player[ide]["team"]}**\n> - **Points :** **{player[ide]["points"]}**")
    except:
        await ctx.reply(f"{name}, não e um jogador registrado")

@bot.command()
async def party(ctx, valuex):
    ide = str(ctx.author.id)
    name = (f"<@{ide}>")
    with open ("player.json", "r") as f:
        playerx = json.load(f)

    
    pt = playerx[ide]["points"]
    points1 = playerx[ide]["value"]
    points2 = int(valuex) * 1000
    
    playerx[ide]["value"] = int(points1) + int(points2)
    playerx[ide]["points"] = int(valuex) + int(pt)

    with open ("player.json", "w") as f:
        json.dump(playerx, f, indent=4)

    await ctx.reply(f"Jogador {name}, agora tem o valor de **{playerx[ide]["value"]}**")

bot.run(token)