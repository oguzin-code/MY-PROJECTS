import discord
from discord.ext import commands
import json
from datetime import date
import random


with open("config.json", "r") as f:
    config = json.load(f)
    token = config["token"]
    channell = config["players_channel"]
    scoreboard = config["scoreboard"]
    color1 = config["color1"]
    color2 = config["color2"]
    color3 = config["color3"]
    season = config["Season"]


intents = discord.Intents.all()
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.command()
@commands.has_permissions(administrator=True)
async def team(ctx, name, owner: discord.Member):

    ide = str(ctx.author.id)
    ownerx = str(owner.id)

    with open("leaderboard.json", "r") as f:
        teams = json.load(f)

        teams[name] =  0

    ide = str(ctx.author.id)

    with open("teams.json", "r") as f:
        times = json.load(f)

    times[name] ={
        "jogadores": [],
        "money": 2000000
        }
    
    with open ("teams.json", "w") as f:
        json.dump(times, f, indent=4)

    with open("leaderboard.json", "w") as f:
        json.dump(teams, f, indent=4)

    cores = ["teal", "green", "blue", "purple", "magenta", "gold", "orange", "red", "yellow", "fuchsia"]
    cores_random = random.choice(cores)
    cor_final = getattr(discord.Colour, cores_random)()

    owner_team = await ctx.guild.create_role(name=(f"👑 ・ {name}"), colour=(cor_final))
    player_team = await ctx.guild.create_role(name=(f"⚽ ・ {name}"), colour=(cor_final))
    await owner.add_roles(owner_team, player_team)


    with open("player.json", "r") as f:
        player = json.load(f)

        player[str(ownerx)]["team"] = (name)
        player[str(ownerx)]["team_owner"] = "True"
        player[str(ownerx)]["cargo_id"] = player_team.id

    with open ("player.json", "w") as f:
        json.dump(player, f, indent=4)

    ch_id = int(player[ownerx]["id_msg"])
    thread = await bot.fetch_channel(ch_id)

    msg_id = int(player[ownerx]["id_msg"])
    msg = await thread.fetch_message(msg_id)
    titulo1 = player[ownerx]["title"]
    titulo2 = ", ".join(titulo1)

    embedx = discord.Embed(

        description=(f"# <:641913member:1503221911222620190> - Jogador : <@{ownerx}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[ownerx]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[ownerx]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[ownerx]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[ownerx]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
        color=int(color2, 16)
        )
    embed2 = discord.Embed(
        description=(f"Olá <@{ownerx}>, seu time")

    )

    await msg.edit(embed=embedx)
    await ctx.reply(f"Time **{name}** criado, Dono atribuido a **{owner}** ")

@bot.command()
@commands.has_permissions(administrator=True)
async def victory(ctx, team1, point1, team2, point2):
    def league_upd():
        with open ("leaderboard.json", "r"):
            teams = json.load(f)
        league_sorted = sorted(teams.items(), key=lambda item: item[1], reverse=True)

        msg = "" 
    
        for i, (team, score) in enumerate(league_sorted, start=1):
            msg += f"> **{i} - ** {team} - **{score}** pts\n"

    try:
        with open("leaderboard.json", "r") as f:
            teams = json.load(f)
            tm1 = (teams[team1])
            tm2 = (teams[team2])

            if (point1) > (point2):
                with open("leaderboard.json","w") as f:
                    teams[team1] += 3
                    json.dump(teams, f, indent=4)
                    await ctx.send(f"O time {team1} ganhou 3 pontos")

                with open("teams.json", "r") as f:
                    team = json.load(f)
                    team[tm1]["money"] += 250000
                with open("teams.json", "w") as f:
                    json.dump(team, f, indent=4)

            elif (point1) < (point2):
                
                with open("leaderboard.json","w") as f:
                    teams[team2] += 3
                    json.dump(teams, f, indent=4)
                    await ctx.send(f"O time {team2} ganhou 3 pontos")

                with open("teams.json", "r") as f:
                    team = json.load(f)
                    team[tm2]["money"] += 250000

                with open("teams.json", "w") as f:
                    json.dump(team, f, indent=4)

            elif (point1) == (point2):
                with open("leaderboard.json", "w") as f:
                    teams[team1] += 1
                    teams[team2] += 1
                    json.dump(teams, f, indent=4)
                    await ctx.send(f"Houve um empate, ambos os times {team1} e {team2}, ganharam 1 ponto na liga")

                with open("teams.json", "r") as f:
                    team = json.load(f)
                team[tm1]["money"] += 125000
                team[tm2]["money"] += 125000
                    
                with open("teams.json", "w") as f:
                    json.dump(team, f, indent=4)
                
    except KeyError:
        await ctx.send("Time não encontrado")

@bot.command()
async def register(ctx):
    player_guild = ctx.guild.get_role(1503052313089015891)

    ide = str(ctx.author.id)
    name = ctx.author.name
 
    with open ("player.json", "r") as f:
        player = json.load(f)
    if ide not in player:

        player[ide] = {

        "discord_name": (name),
        "value": 0,
        "team": "Nenhum",
        "points": 0,
        "id_msg": 0,
        "free_agent": "Yes",
        "title":[]

        }

        player[ide]["title"].append("Nenhum")

        forum = bot.get_channel(channell)
        titulo1 = player[ide]["title"]
        titulo2 = ", ".join(titulo1)

        embed = discord.Embed(
            description=(f"# <:641913member:1503221911222620190> - Jogador : <@{ide}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[ide]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[ide]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[ide]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[ide]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
            color=int(color2, 16)
        )

        msg_bot = await forum.create_thread(
                name=(f"Jogador - **{name}**"),
                content="",
                embed=embed
        )       

        idexx = int(msg_bot.message.id)

        player[ide]["id_msg"] = idexx
        

        with open("player.json", "w") as f:
            json.dump(player, f, indent=4)

            await ctx.author.add_roles(player_guild)

        await ctx.reply("**Você foi registrado com sucesso**")

    else:
        await ctx.reply("**Você já ta registrado**")

@bot.command()
async def search(ctx, nick: discord.Member):
    
    ide = str(nick.id)
    name = str(f"<@{ide}>")
    try:
        with open("player.json", "r") as f:
            player = json.load(f)

        id_aura = player[ide]["id_msg"]

        canal = bot.get_channel(int(id_aura))
        msg = await canal.fetch_message(id_aura)

        titulo1 = player[ide]["title"]
        titulo2 = ", ".join(titulo1)

        embed = discord.Embed(
            description=(f"# <:641913member:1503221911222620190> - Jogador : <@{ide}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[ide]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[ide]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[ide]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[ide]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
            color=int(color2, 16)
        )
        await ctx.reply(embed=embed)

    except:
        await ctx.reply(f"{name}, não e um jogador registrado")

@bot.command()
@commands.has_permissions(administrator=True)
async def points(ctx, member: discord.Member, valuex):

    try:

        ide = str(member.id)
        name = (f"<@{ide}>")

        with open ("player.json", "r") as f:
            player = json.load(f)

        pt = player[ide]["points"]
        points1 = player[ide]["value"]
        points2 = int(valuex) * 100
    
        player[ide]["value"] = int(points1) + int(points2)
        player[ide]["points"] = int(valuex) + int(pt)

        with open ("player.json", "w") as f:
            json.dump(player, f, indent=4)

        thread = await bot.fetch_channel(player[ide]["id_msg"])
        msg = await thread.fetch_message(player[ide]["id_msg"])

        embed = discord.Embed(
            description=(f"# <:641913member:1503221911222620190> - Jogador : **<@{ide}>**\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[ide]["value"]}**\n> <:304671rank:1503222908149829733> - **Time :** **{player[ide]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[ide]["points"]}**\n> <:freeagent:1503537488894099497> - **Agente Livre:** **{player[ide]["free_agent"]}** \n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
            color=int(color2, 16)
        )

        await msg.edit(embed=embed)
        await ctx.reply(f"Jogador {name}, agora tem o valor de **{player[ide]["value"]}**")


    except:
    
        ide = str(ctx.author.id)
        name = (f"<@{ide}>")


        with open ("player.json", "r") as f:
            player = json.load(f)

    
        pt = player[ide]["points"]
        points1 = player[ide]["value"]
        points2 = int(valuex) * 1000
    
        player[ide]["value"] = int(points1) + int(points2)
        player[ide]["points"] = int(valuex) + int(pt)

        with open ("player.json", "w") as f:
            json.dump(player, f, indent=4)

        thread = await bot.fetch_channel(player[ide]["id_msg"])
        msg = await thread.fetch_message(player[ide]["id_msg"])

        embed = discord.Embed(
            description=(f"# <:641913member:1503221911222620190> - Jogador : **<@{ide}>**\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[ide]["value"]}**\n> <:304671rank:1503222908149829733> - **Time :** **{player[ide]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[ide]["points"]}**\n> <:freeagent:1503537488894099497> - **Agente Livre:** **{player[ide]["free_agent"]}** \n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
            color=int(color2, 16)
        )

        await msg.edit(embed=embed)
        await ctx.reply(f"Jogador {name}, agora tem o valor de **{player[ide]["value"]}**")

@bot.command()
async def contratar(ctx, jogador: discord.Member):
    owner_id = str(ctx.author.id)
    player_id = str(jogador.id)
    
    
    with open("player.json", "r") as f:
        player = json.load(f)
    
    time_antigo = player[player_id]["team"]
    agente_livre = player[player_id].get("free_agent")
    valor_player = int(player[player_id]["value"])
    owner_team = player[owner_id]["team"]
    is_owner = player[owner_id].get("team_owner")
    time_jogador = player[player_id].get("team")
    with open("teams.json", "r") as f:
        team = json.load(f)
        
    valor_team = int(team[owner_team]["money"])

    if player_id not in player:
        await ctx.reply("Este jogador não está registrado")

    if is_owner != "True":
        return await ctx.reply("Você não e dono de um time")
    
    elif valor_team < valor_player:
        return await ctx.reply("Você não tem saldo o suficiente para contratar o jogador")
    
    elif agente_livre == "No":
        return await ctx.reply("**As configurações de transferencia deste jogador está como OFF, ou seja ele não quer receber propostas no momento**")

    elif time_jogador == owner_team:
        return await ctx.reply("Este jogador já joga no seu time")

    elif is_owner == "True" and player_id in player and agente_livre == "Yes":

        try:
            is_owner_player = player[player_id]["team_owner"]
            if is_owner_player == "True":
                return await ctx.reply("Você não pode convidar outros treinadores")
        except:
            print("You can't invite treiner")    
        
        view = discord.ui.View()
        botao = discord.ui.Button(label="Aceitar contrato", style=discord.ButtonStyle.green)
        async def clicar(interaction: discord.Interactions):
            botao.disabled = True
            botao.label = "Contrato Aceito"
            botao.style = discord.ButtonStyle.gray
            Bnegar.disabled = True
            await interaction.response.edit_message(view=view)

            await jogador.send(f"Contrato aceito, apartir de agora você faz parte do time **{owner_team}**")

            with open("player.json", "r") as f:
                player = json.load(f)

            titulo1 = player[player_id]["title"]
            titulo2 = ", ".join(titulo1) 

            try:
                carginho_antigo = player[player_id]["cargo_id"]
                carginhoi_2 = ctx.guild.get_role(int(carginho_antigo))
                await jogador.remove_roles(carginhoi_2)

            except:
                print("jogador não tem cargo antigo")
        
            player[player_id]["team"] = owner_team
            valor_player = player[player_id]["value"]
            id_edit = player[player_id]["id_msg"]
            cargox_id = player[owner_id]["cargo_id"]
            player[player_id]["cargo_id"] = int(cargox_id)

            with open("player.json", "w") as f:
                json.dump(player, f, indent=4)

            with open("teams.json", "r") as f:
                team = json.load(f)

            team[owner_team]["jogadores"].append(str(player_id))
            team[owner_team]["money"] -= int(valor_player)

            with open("teams.json", "w") as f:
                json.dump(team, f, indent=4)
            
            

            carginho = ctx.guild.get_role(int(cargox_id))
            
            await jogador.add_roles(carginho)

            mandar = await bot.fetch_user(owner_id)

            await mandar.send(f"**Jogador, {jogador} aceitou sua proposta de ser jogador do {owner_team}, entre em contato com ele para acertarem os últimos detalhes e dar inicio nessa nova jornada**")
            trans = bot.get_channel(1503037635159916664)
            embed = discord.Embed(
                description=(f"<:Transferr:1503530135977066537> |  O jogador **<@{player_id}>**, saiu do seu time **{time_antigo}** para **{owner_team}**"),
                color=int(color1, 16)
            )

            thread = await bot.fetch_channel(player[player_id]["id_msg"])
            msg = await thread.fetch_message(player[player_id]["id_msg"])

            embed1 = discord.Embed(
                description=(f"# <:641913member:1503221911222620190> - Jogador : <@{player_id}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[player_id]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[player_id]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[player_id]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[player_id]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"
),
                color = int(color2, 16)
            )
            
            await msg.edit(embed=embed1)
            await trans.send(embed=embed)

        Bnegar = discord.ui.Button(label="Negar", style=discord.ButtonStyle.red)

        async def negar(interaction: discord.Interactions):

            Bnegar.disabled = True
            Bnegar.style = discord.ButtonStyle.gray
            botao.disabled = True
            await interaction.response.edit_message(view=view)
            await jogador.send("Recusado com sucesso")
            mandar = await bot.fetch_user(owner_id)
            await mandar.send(f"O jogador **{jogador}**, recusou sua proposta")



        view.add_item(botao)
        view.add_item(Bnegar)
        botao.callback = clicar
        Bnegar.callback = negar
        embed = discord.Embed(
            description=(f"Olá <@{player_id}>, Voçê acaba de receber uma proposta de contratação do time **{owner_team}**, deseja aceitar a proposta?"),
            color=int(color3, 16)
            )
        await jogador.send(embed=embed, view=view,)
        await ctx.reply("**Proposta enviada, aguarde a respota, irei te atualizar no privado**")
    else:
        await ctx.reply(f"O jogador <@{player_id}>, não está registrado")


@bot.command()
async def leaderboard(ctx):
    with open ("leaderboard.json", "r") as f:
        leader = json.load(f)

    leaderx = sorted(leader.items(), key=lambda item: item[1], reverse=True)

    leaderboardex = ""

    for posi, (leader, pontos) in enumerate(leaderx, 1):

        leaderboardex += (f"**{posi}** - {leader} |  **{pontos}** pts \n")
        datex = date.today()

        embed = discord.Embed(
            title="Season 1",
            description=(f"### <:Trofeu:1503137351738593470>  |   Classificaçâo\n {leaderboardex}\n-# Ultima atualização: **{datex}** "),
            color=(int(color1, 16))
        )
    await ctx.send(embed=embed)
    await ctx.message.delete()

@bot.command()
async def bank(ctx, teaming):

    with open("teams.json", "r") as f:
        teams = json.load(f)

    pay = teams[teaming].get("money")

    await ctx.reply(f"O time **{teaming}** tem em seu banco: **{pay}**")

@bot.command()
async def transfer(ctx, op):

    ide = str(ctx.author.id)

    if op == "Off":
        with open("player.json", "r") as f:
            player = json.load(f)

        player[ide]["free_agent"] = "No"

        with open("player.json", "w") as f:
            json.dump(player, f, indent=4)

        thread = await bot.fetch_channel(player[ide]["id_msg"])
        msg = await thread.fetch_message(player[ide]["id_msg"])

        titulo1 = player[ide]["title"]
        titulo2 = ", ".join(titulo1)

        embed = discord.Embed(
            description=(f"# <:641913member:1503221911222620190> - Jogador : <@{ide}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[ide]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[ide]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[ide]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[ide]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
            color=int(color2, 16)
        )
        await msg.edit(embed=embed)
        await ctx.reply("**Suas configurações foram configuradas como OFF, apartir de agora você não recebera mais propostas de times, se quiser receber coloque como ON**")

    elif op == "On":
        with open("player.json", "r") as f:
            player = json.load(f)

        player[ide]["free_agent"] = "Yes"

        with open("player.json", "w") as f:
            json.dump(player, f, indent=4)

        thread = await bot.fetch_channel(player[ide]["id_msg"])
        msg = await thread.fetch_message(player[ide]["id_msg"])
        
        titulo1 = player[ide]["title"]
        titulo2 = ", ".join(titulo1)

        embed = discord.Embed(
            description=(f"# <:641913member:1503221911222620190> - Jogador : <@{ide}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[ide]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[ide]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[ide]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[ide]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
            color=int(color2, 16)
        )

        await msg.edit(embed=embed)
        await ctx.reply("**Suas configurações foram definidas como ON, você pode receber propostas de times a qualquer momento, se não quiser receber coloque como OFF**")

    else:
        ctx.reply("Use apenas !transfer On ou Off")

@bot.command()
async def pay(ctx, team, valor):
    author = str(ctx.author.id)

    with open("player.json", "r") as f:
        player = json.load(f)
        owner_team = player[author]["team"]
        recipient_team = team
        if_owner = player[author]["team_owner"]

    with open("teams.json", "r") as f:
        teams = json.load(f)
        author_money = int(teams[owner_team]["money"])
        valuor = int(valor)
    try:
        if author_money < valuor:
            await ctx.reply("Você tem saldo insuficiente")

        if author_money >= valuor:

            if if_owner == "True":
                with open("teams.json", "r") as f:
                    teams = json.load(f)
        
                teams[team]["money"] += valuor
                teams[owner_team]["money"] -= valuor

                with open("teams.json", "w") as f:
                        json.dump(teams, f, indent=4)
                new_value = teams[owner_team]["money"]
                await ctx.reply(f"Transferência concluida de **{valor}** concluida, seu saldo atual e de **{new_value}**")
            else:
                await ctx.reply("Você não e dono de um time")
    except KeyError:
        await ctx.reply(f"Time {team} não encontrado")


@bot.command()
@commands.has_permissions(administrator=True)
async def title(ctx, title_name, jogador: discord.Member):

    jogador_id = str(jogador.id)
    jogador_int = int(jogador.id)

    try:

        with open("player.json", "r") as f:
            player = json.load(f)


        titles = player[jogador_id]["title"]
        if "Nenhum" in titles:
            titles.remove("Nenhum")
        player[jogador_id]["title"].append(f"{title_name} - {season}")
        titulo1 = player[jogador_id]["title"]
        titulo2 = ", ".join(titulo1)

        with open("player.json", "w") as f:
            json.dump(player, f, indent=4)

        await ctx.reply(f"O titulo **{title_name}** foi adicionado na **Galeria de Títulos** de <@{jogador_int}>")

        thread = await bot.fetch_channel(player[jogador_id]["id_msg"])
        msg = await thread.fetch_message(player[jogador_id]["id_msg"])

        embed = discord.Embed(
            description=(f"# <:641913member:1503221911222620190> - Jogador : <@{jogador_id}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[jogador_id]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[jogador_id]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[jogador_id]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[jogador_id]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
            color=int(color2, 16)
        )

        thread = await bot.fetch_channel(player[jogador_id]["id_msg"])
        msg = await thread.fetch_message(player[jogador_id]["id_msg"])

        msg.edit(embed=embed)

    except KeyError:
        await ctx.reply("Jogador não está registrado na liga")

@bot.command()
async def kick(ctx, user: discord.Member,*, motive="Não informado"):
    author_id = str(ctx.author.id)
    player_id = str(user.id)
    try:

        with open("player.json", "r") as f:
            player = json.load(f)

        if_owner = player[author_id]["team_owner"]
        player_team = player[player_id]["team"]
        author_team = player[author_id]["team"]
        if player_id == author_id:
            return await ctx.reply("Você não pode sair do propio time")
        
        elif player_team != author_team:
            return await ctx.reply("Você não pode expulsar pessoas de outros times")

        elif if_owner == "True":
            with open("player.json", "r") as f:
                player = json.load(f)
            old_team = player[author_id]["team"]

            player[player_id]["team"] = "Nenhum"
            cargo_id = int(player[player_id]["cargo_id"])
            cargo_get = ctx.guild.get_role(cargo_id)
            await user.remove_roles(cargo_get)
        

            thread = await bot.fetch_channel(player[player_id]["id_msg"])
            msg = await thread.fetch_message(player[player_id]["id_msg"])
        
            titulo1 = player[player_id]["title"]
            titulo2 = ", ".join(titulo1)

            embed = discord.Embed(
                description=(f"# <:641913member:1503221911222620190> - Jogador : <@{player_id}>\n > <:178616member:1503222244866916432> - **Valor de mercado : ** **{player[player_id]["value"]}**\n > <:304671rank:1503222908149829733> - **Time :** **{player[player_id]["team"]}**\n> <:4677star:1503223594954653776> - **Points :** **{player[player_id]["points"]}**\n > <:freeagent:1503537488894099497> - **Agente Livre:** **{player[player_id]["free_agent"]}** \n > <:Titulos:1504255998003642379> - **Titulos : ** **{titulo2}**\n ``` Use !contratrar @jogador, Para contrata-lo pro seu time```"),
                color=int(color2, 16)
            )
            with open("player.json", "w") as f:
                json.dump(player, f, indent=4)

            trans = bot.get_channel(1503037635159916664)
            embed2 = discord.Embed(
                    description=(f"<:Transferr:1503530135977066537> |  O jogador **<@{player_id}>**, saiu do seu time **{old_team}** para **Nenhum**"),
                    color=int(color1, 16)
                )
            await trans.send(embed=embed2)
            await msg.edit(embed=embed)
            await user.send(f"**Olá <@{player_id}>, você foi expulso do time {old_team}, pelo motivo: {motive}**")
            await ctx.reply(f"Jogador <@{player_id}> foi expulso do time com sucesso")

            
        elif if_owner != "True":
            return await ctx.reply("Você não tem permissão para usar esse comando")
        
    except KeyError:
        await ctx.reply("Erro, usuario não encontrado")


@bot.event
async def on_member_remove(member):
    with open("player.json", "r") as f:
        player = json.load(f)

    player_id = str(member.id)
    id_msg = int(player[player_id]["id_msg"])
    thread = member.guild.get_thread(id_msg)
    owner_team = player[player_id]["team"]
    try:
        if_owner = player[player_id]["team_owner"]
        if if_owner == "True":

            with open("teams.json", "r") as f:
                teams = json.load(f)
            with open("leaderboard.json", "r") as f:
                leaderboard = json.load(f)

            del teams[owner_team]
            del leaderboard[owner_team]
            
            with open("teams.json", "w") as f:
                json.dump(teams, f, indent=4)

            with open("leaderboard.json", "w") as f:
                json.dump(leaderboard, f, indent=4)
    except:
        print("Não achei o baguiu do cabinha")

    await thread.delete()
    del player[player_id]
    with open("player.json", "w") as f:
        json.dump(player, f, indent=4)

    
        
bot.run(token)